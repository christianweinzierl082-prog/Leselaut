package de.leselaut.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { LeseLautScreen() } } }
    }
}

@Composable
private fun LeseLautScreen() {
    val context = LocalContext.current
    var recognizedText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Fotografiere eine Seite oder wähle ein Bild aus.") }
    var busy by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var speechRate by remember { mutableFloatStateOf(0.9f) }
    var ttsReady by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var resumeAt by remember { mutableIntStateOf(0) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
            if (result == TextToSpeech.SUCCESS) {
                val languageResult = tts?.setLanguage(Locale.GERMAN)
                if (languageResult == TextToSpeech.LANG_MISSING_DATA ||
                    languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    status = "Auf diesem Gerät ist keine deutsche Stimme verfügbar. Bitte installiere deutsche Sprachdaten in den Android-Einstellungen."
                }
            }
        }
        tts = engine
        engine.setLanguage(Locale.GERMAN)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true; paused = false }
            override fun onDone(utteranceId: String?) { speaking = false; paused = false; resumeAt = 0 }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { speaking = false }
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                resumeAt = start
            }
        })
        onDispose {
            engine.stop()
            engine.shutdown()
            tts = null
        }
    }

    fun readImage(uri: Uri) {
        busy = true
        status = "Text wird erkannt …"
        try {
            val image = InputImage.fromFilePath(context, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    recognizedText = result.text
                    status = if (result.text.isBlank()) "Kein Text gefunden. Bitte fotografiere die Seite noch einmal bei gutem Licht."
                    else "Text erkannt. Du kannst ihn vorlesen lassen oder bei Bedarf bearbeiten."
                    busy = false
                    recognizer.close()
                }
                .addOnFailureListener { error ->
                    status = "Texterkennung fehlgeschlagen: ${error.localizedMessage ?: "Bitte anderes Bild versuchen."}"
                    busy = false
                    recognizer.close()
                }
        } catch (e: Exception) {
            status = "Bild konnte nicht geöffnet werden: ${e.localizedMessage ?: "Unbekannter Fehler"}"
            busy = false
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) readImage(uri)
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) readImage(uri)
        else status = "Foto wurde nicht übernommen."
    }

    fun startReading(from: Int = 0) {
        val engine = tts
        if (engine == null || !ttsReady) {
            status = "Sprachausgabe wird noch vorbereitet. Bitte gleich noch einmal tippen."
            return
        }
        if (recognizedText.isBlank()) {
            status = "Bitte zuerst eine Seite fotografieren oder ein Bild auswählen."
            return
        }
        engine.stop()
        engine.language = Locale.GERMAN
        engine.setSpeechRate(speechRate)
        val text = recognizedText.substring(from.coerceIn(0, recognizedText.length))
        if (text.isBlank()) {
            resumeAt = 0
            return
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "leselaut-${System.currentTimeMillis()}")
        speaking = true
        paused = false
        status = "Ich lese vor …"
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("LeseLaut", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Fotografieren. Erkennen. Vorlesen.", style = MaterialTheme.typography.titleMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            try {
                                val directory = File(context.cacheDir, "images").apply { mkdirs() }
                                val photo = File.createTempFile("leselaut_", ".jpg", directory)
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", photo)
                                pendingCameraUri = uri
                                cameraLauncher.launch(uri)
                            } catch (e: Exception) {
                                status = "Kamera konnte nicht gestartet werden: ${e.localizedMessage ?: "Fehler"}"
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(Modifier.height(1.dp))
                        Text(" Foto")
                    }
                    OutlinedButton(onClick = { galleryLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) {
                        androidx.compose.material3.Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Text(" Bild wählen")
                    }
                }
                if (busy) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator()
                        Text("Bitte kurz warten …")
                    }
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Text("Erkannter Text", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        TextField(
            value = recognizedText,
            onValueChange = { recognizedText = it },
            modifier = Modifier.fillMaxWidth().height(250.dp),
            placeholder = { Text("Hier erscheint der erkannte Text. Du kannst ihn auch korrigieren.") },
            label = { Text("Text (bearbeitbar)") }
        )

        Text("Lesegeschwindigkeit", style = MaterialTheme.typography.titleMedium)
        Text(
            when {
                speechRate < 0.8f -> "Langsam"
                speechRate > 1.05f -> "Schneller"
                else -> "Natürlich"
            }
        )
        Slider(value = speechRate, onValueChange = { speechRate = it }, valueRange = 0.6f..1.3f)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { startReading(if (paused) resumeAt else 0) },
                modifier = Modifier.weight(1f),
                enabled = recognizedText.isNotBlank()
            ) {
                androidx.compose.material3.Icon(Icons.Default.PlayArrow, contentDescription = null)
                Text(if (paused) "Weiter" else "Vorlesen")
            }
            OutlinedButton(
                onClick = {
                    if (speaking) {
                        tts?.stop()
                        paused = true
                        speaking = false
                        status = "Pausiert. Tippe auf „Weiter“, um fortzufahren."
                    }
                },
                modifier = Modifier.weight(1f),
                enabled = speaking
            ) {
                androidx.compose.material3.Icon(Icons.Default.Pause, contentDescription = null)
                Text("Pause")
            }
            OutlinedButton(
                onClick = {
                    tts?.stop()
                    speaking = false
                    paused = false
                    resumeAt = 0
                    status = "Vorlesen gestoppt."
                },
                enabled = speaking || paused
            ) {
                androidx.compose.material3.Icon(Icons.Default.Stop, contentDescription = null)
                Text("Stopp")
            }
        }
        Text(
            "Hinweis: Die Texterkennung läuft auf dem Gerät. Die verfügbare Stimme und Aussprache hängen von den installierten Android-Sprachdaten ab.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
